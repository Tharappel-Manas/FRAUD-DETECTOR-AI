"""
Feature engineering for the fraud-spike detector.

The ULB credit card dataset has no card/merchant ID -- only Time, 28 PCA
components (V1-V28), Amount, and the label. That rules out true per-account
velocity features. Instead we build POPULATION-LEVEL burst/velocity features
from the Time column: how many transactions (and how much value) landed in
the seconds just before this one. This is a real fraud signal in payment
systems (e.g. card-testing attacks show up as short bursts of small
transactions) even without entity-level identifiers.

If a card/merchant ID were available (e.g. the IEEE-CIS dataset), the same
windowing logic below should be applied per-entity instead of globally --
that is the natural upgrade path and is called out in the README.
"""
import numpy as np
import pandas as pd


def add_burst_features(df: pd.DataFrame) -> pd.DataFrame:
    """Add trailing-window transaction count/volume features based on Time.

    Assumes df is sorted ascending by 'Time' (verified at load time).
    Windows are computed with a two-pointer sliding window -> O(n).
    """
    df = df.copy().reset_index(drop=True)
    time = df["Time"].values
    amount = df["Amount"].values
    n = len(df)

    windows_sec = {"60s": 60, "300s": 300, "3600s": 3600}
    for label, w in windows_sec.items():
        counts = np.zeros(n, dtype=np.int64)
        sums = np.zeros(n, dtype=np.float64)
        left = 0
        running_sum = 0.0
        for right in range(n):
            # shrink window from the left while it's outside [time[right]-w, time[right])
            while time[left] <= time[right] - w:
                running_sum -= amount[left]
                left += 1
            # window is [left, right) -- transactions strictly before 'right'
            counts[right] = right - left
            sums[right] = running_sum
            running_sum += amount[right]
        df[f"txn_count_prior_{label}"] = counts
        df[f"txn_amount_sum_prior_{label}"] = sums

    # time since previous transaction (global) -- 0 for the first row
    df["time_since_prev_txn"] = df["Time"].diff().fillna(0).clip(lower=0)

    # diurnal pattern -- Time is seconds elapsed since the first transaction
    df["hour_of_day"] = (df["Time"] % 86400) // 3600

    # amount is heavily right-skewed
    df["log_amount"] = np.log1p(df["Amount"])

    return df


def build_feature_matrix(df: pd.DataFrame):
    """Return (X, y, feature_names) with burst features added."""
    df = add_burst_features(df)
    drop_cols = ["Class", "Time", "Amount"]
    feature_cols = [c for c in df.columns if c not in drop_cols]
    X = df[feature_cols]
    y = df["Class"]
    return X, y, feature_cols
