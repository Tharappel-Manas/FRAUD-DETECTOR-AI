"""
Evaluate the fraud-spike detector honestly:
  1. Threshold-independent: PR-AUC (not ROC-AUC, which is misleading at
     0.1-0.2% base rate -- a model can have ROC-AUC 0.98 while still being
     useless in production because precision at any usable recall is low).
  2. Threshold-dependent: pick the operating point by minimizing EXPECTED
     BUSINESS COST, not by F1 or "default 0.5". Cost assumptions are stated
     explicitly below so they can be swapped for real Razorpay numbers.
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import (
    average_precision_score, precision_recall_curve, roc_auc_score,
    confusion_matrix, precision_score, recall_score, f1_score
)

# ---- Cost assumptions (state these explicitly -- swap in real figures) ----
# False negative: fraud goes through undetected -> lose the transaction amount.
# False positive: a genuine transaction gets flagged -> cost of manual review
#   / customer friction / support contact. Flat cost, since blocking a ₹50
#   coffee purchase and a ₹50,000 purchase cost the platform roughly the same
#   in review effort even though the customer impact differs.
FP_COST = 50.0  # INR, flat review/friction cost per false positive


def cost_at_threshold(y_true, proba, amounts, threshold):
    pred = (proba >= threshold).astype(int)
    fn_mask = (pred == 0) & (y_true == 1)
    fp_mask = (pred == 1) & (y_true == 0)
    fn_cost = amounts[fn_mask].sum()          # lost fraud amount
    fp_cost = fp_mask.sum() * FP_COST          # flat review cost
    return fn_cost + fp_cost, fn_mask.sum(), fp_mask.sum()


def main():
    y_test = np.load("outputs/y_test.npy")
    proba_test = np.load("outputs/proba_test.npy")
    test_df = pd.read_csv("outputs/test_predictions.csv")
    amounts = test_df["Amount"].values

    ap = average_precision_score(y_test, proba_test)
    roc = roc_auc_score(y_test, proba_test)
    print(f"PR-AUC (average precision): {ap:.4f}")
    print(f"ROC-AUC:                    {roc:.4f}  (reported for context only -- "
          f"misleading alone at this class imbalance)")

    # --- sweep thresholds for cost minimization ---
    thresholds = np.linspace(0.01, 0.99, 197)
    costs, fns, fps = [], [], []
    for t in thresholds:
        c, fn, fp = cost_at_threshold(y_test, proba_test, amounts, t)
        costs.append(c)
        fns.append(fn)
        fps.append(fp)
    costs = np.array(costs)
    best_idx = costs.argmin()
    best_t = thresholds[best_idx]

    # cost of two naive baselines for comparison
    cost_flag_none, fn_none, fp_none = cost_at_threshold(y_test, proba_test, amounts, 1.01)
    cost_flag_all, fn_all, fp_all = cost_at_threshold(y_test, proba_test, amounts, -0.01)

    pred_best = (proba_test >= best_t).astype(int)
    prec = precision_score(y_test, pred_best)
    rec = recall_score(y_test, pred_best)
    f1 = f1_score(y_test, pred_best)
    cm = confusion_matrix(y_test, pred_best)

    print(f"\n--- Cost-optimal operating point ---")
    print(f"Threshold:  {best_t:.3f}")
    print(f"Precision:  {prec:.3f}")
    print(f"Recall:     {rec:.3f}")
    print(f"F1:         {f1:.3f}")
    print(f"Confusion matrix [ [TN FP] [FN TP] ]:\n{cm}")
    print(f"\nExpected cost at optimal threshold: Rs.{costs[best_idx]:,.0f}")
    print(f"Cost of flagging NOTHING (miss all fraud): Rs.{cost_flag_none:,.0f}")
    print(f"Cost of flagging EVERYTHING (block all txns): Rs.{cost_flag_all:,.0f}")
    savings_vs_none = cost_flag_none - costs[best_idx]
    print(f"Savings vs. doing nothing: Rs.{savings_vs_none:,.0f} "
          f"({savings_vs_none/cost_flag_none*100:.1f}% cost reduction)")

    # --- plots ---
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))

    precisions, recalls, pr_thresholds = precision_recall_curve(y_test, proba_test)
    axes[0].plot(recalls, precisions, color="#1f4e79")
    axes[0].scatter([rec], [prec], color="#c0392b", zorder=5, label=f"chosen op. point (t={best_t:.2f})")
    axes[0].set_xlabel("Recall")
    axes[0].set_ylabel("Precision")
    axes[0].set_title(f"Precision-Recall curve (PR-AUC = {ap:.3f})")
    axes[0].legend()
    axes[0].grid(alpha=0.3)

    axes[1].plot(thresholds, costs, color="#1f4e79")
    axes[1].axvline(best_t, color="#c0392b", linestyle="--", label=f"min cost @ t={best_t:.2f}")
    axes[1].set_xlabel("Decision threshold")
    axes[1].set_ylabel("Expected cost (Rs.)")
    axes[1].set_title("Expected business cost vs. threshold")
    axes[1].legend()
    axes[1].grid(alpha=0.3)

    im = axes[2].imshow(cm, cmap="Blues")
    axes[2].set_xticks([0, 1]); axes[2].set_xticklabels(["Pred: Legit", "Pred: Fraud"])
    axes[2].set_yticks([0, 1]); axes[2].set_yticklabels(["True: Legit", "True: Fraud"])
    for i in range(2):
        for j in range(2):
            axes[2].text(j, i, f"{cm[i, j]:,}", ha="center", va="center",
                         color="white" if cm[i, j] > cm.max()/2 else "black", fontsize=14)
    axes[2].set_title(f"Confusion matrix @ t={best_t:.2f}")

    plt.tight_layout()
    plt.savefig("outputs/evaluation_plots.png", dpi=150)
    print("\nSaved plots to outputs/evaluation_plots.png")

    summary = {
        "pr_auc": ap, "roc_auc": roc, "best_threshold": best_t,
        "precision": prec, "recall": rec, "f1": f1,
        "fn_at_best": int(fns[best_idx]), "fp_at_best": int(fps[best_idx]),
        "expected_cost": float(costs[best_idx]),
        "cost_flag_none": float(cost_flag_none),
        "savings_pct_vs_none": float(savings_vs_none/cost_flag_none*100),
    }
    pd.Series(summary).to_json("outputs/metrics_summary.json", indent=2)


if __name__ == "__main__":
    main()
