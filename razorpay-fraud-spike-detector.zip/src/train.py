"""
Train the fraud-spike detector.

Split strategy: TIME-BASED, not random. A random split lets the model see
transactions from both before and after any given fraud pattern, which
leaks information a production model wouldn't have (it only ever sees the
past). We train on the first 70% of the 2-day window and test on the
trailing 30% -- a more honest simulation of "held-out" performance.
"""
import sys
import joblib
import numpy as np
import pandas as pd
from xgboost import XGBClassifier

sys.path.insert(0, "src")
from features import build_feature_matrix  # noqa: E402


def time_based_split(df: pd.DataFrame, train_frac: float = 0.7):
    cutoff = df["Time"].quantile(train_frac)
    train_df = df[df["Time"] <= cutoff].reset_index(drop=True)
    test_df = df[df["Time"] > cutoff].reset_index(drop=True)
    return train_df, test_df


def main():
    df = pd.read_csv("data/creditcard.csv")
    train_df, test_df = time_based_split(df, train_frac=0.7)

    print(f"Train: {len(train_df):,} rows, {train_df['Class'].sum()} fraud "
          f"({train_df['Class'].mean()*100:.3f}%)")
    print(f"Test:  {len(test_df):,} rows, {test_df['Class'].sum()} fraud "
          f"({test_df['Class'].mean()*100:.3f}%)")

    # Burst features must be computed on the FULL chronological series
    # (a transaction's "prior 5 min" can include train-period transactions
    # even if the transaction itself is in the test period) and then split.
    X_all, y_all, all_feature_cols = build_feature_matrix(df)

    # Ablation (see notebooks/fraud_spike_detection.ipynb) showed the
    # population-level burst/velocity features give NO measurable PR-AUC
    # lift on this dataset (0.814 without vs 0.801 with) -- likely because
    # there's no entity ID to make the window features entity-specific,
    # and the existing PCA components (V14, V10, V4) already encode most of
    # the separable signal on this well-studied benchmark. We therefore
    # ship the model WITHOUT burst features as the final artifact, and keep
    # the burst-feature code + ablation as a documented negative result and
    # upgrade path for datasets that do have entity IDs (e.g. IEEE-CIS).
    burst_cols = [c for c in all_feature_cols
                  if "txn_count" in c or "txn_amount_sum" in c or "time_since_prev" in c]
    feature_cols = [c for c in all_feature_cols if c not in burst_cols]

    n_train = len(train_df)
    X_train, y_train = X_all.iloc[:n_train][feature_cols], y_all.iloc[:n_train]
    X_test, y_test = X_all.iloc[n_train:][feature_cols], y_all.iloc[n_train:]

    scale_pos_weight = (y_train == 0).sum() / (y_train == 1).sum()
    print(f"\nscale_pos_weight: {scale_pos_weight:.1f}")

    model = XGBClassifier(
        n_estimators=400,
        max_depth=5,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        min_child_weight=3,
        scale_pos_weight=scale_pos_weight,
        eval_metric="aucpr",
        random_state=42,
        n_jobs=-1,
    )
    model.fit(X_train, y_train)

    proba_test = model.predict_proba(X_test)[:, 1]
    proba_train = model.predict_proba(X_train)[:, 1]

    np.save("outputs/y_test.npy", y_test.values)
    np.save("outputs/proba_test.npy", proba_test)
    np.save("outputs/y_train.npy", y_train.values)
    np.save("outputs/proba_train.npy", proba_train)
    test_df_out = test_df.copy()
    test_df_out["fraud_proba"] = proba_test
    test_df_out.to_csv("outputs/test_predictions.csv", index=False)

    joblib.dump(model, "outputs/xgb_fraud_model.joblib")
    joblib.dump(feature_cols, "outputs/feature_cols.joblib")

    print("\nSaved model + predictions to outputs/")


if __name__ == "__main__":
    main()
